from lib.compatibility import register_module

register_module("concurrent.futures", py2_module="script.module.futures")
